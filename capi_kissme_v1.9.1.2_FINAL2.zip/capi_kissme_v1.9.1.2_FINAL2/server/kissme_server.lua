
local Config = Config or {}
local WEBHOOK_URL = Config.Webhook ~= "COLOQUE_AQUI_SEU_WEBHOOK" and Config.Webhook or nil

function GetCharacterName(source)
    if GetResourceState("ox_core") == "started" then
        local user = exports.ox_core:GetPlayer(source)
        return user and (user.firstName .. " " .. user.lastName) or GetPlayerName(source)
    elseif GetResourceState("vorp_core") == "started" then
        local User = exports["vorp_core"]:getUser(source)
        if not User then return GetPlayerName(source) end
        local char = User.getUsedCharacter
        return char and (char.firstname .. " " .. char.lastname) or GetPlayerName(source)
    elseif GetResourceState("rsg-core") == "started" then
        local char = exports["rsg-core"]:GetCharacter(source)
        return char and (char.first_name .. " " .. char.last_name) or GetPlayerName(source)
    end
    return GetPlayerName(source)
end

local function sendWebhookLog(sourceName, targetName, resultado)
    if not WEBHOOK_URL then return end
    PerformHttpRequest(WEBHOOK_URL, function() end, 'POST', json.encode({
        username = "KissMe Logs",
        embeds = {{
            title = "💋 KissMe Log",
            description = ("**%s** tentou beijar **%s**\nResultado: **%s**"):format(sourceName, targetName, resultado),
            color = 14566335
        }}
    }), { ['Content-Type'] = 'application/json' })
end

local function giveLootToPlayer(player)
    if not Config or not Config.LootItems then return end
    local chance = math.random(1, 100)
    for _, item in ipairs(Config.LootItems) do
        if chance <= item.chance then
            local quantidade = item.min or 1
            if item.max and item.max > item.min then
                quantidade = math.random(item.min, item.max)
            end
            if Config.Framework == "vorp" and exports.vorp_inventory then
                exports.vorp_inventory:addItem(player, item.name, quantidade)
            elseif Config.Framework == "rsg" and exports["rsg-inventory"] then
                exports["rsg-inventory"]:AddItem(player, item.name, quantidade)
            elseif Config.Framework == "ox" and exports.ox_inventory then
                exports.ox_inventory:AddItem(player, item.name, quantidade)
            else
                print("[KissMe] Erro: Inventário não encontrado ou framework não suportado.")
            end
            TriggerClientEvent("kissme:notifyLoot", player, item.label)
            sendWebhookLog(GetCharacterName(player), 'NPC Beijado', 'Recebeu loot: ' .. item.label)
            break
        end
    end
end

local cooldowns = {}

RegisterNetEvent('kissme:tryKiss')
AddEventHandler('kissme:tryKiss', function()
    local src = source
    local now = os.time()
    if cooldowns[src] and now - cooldowns[src] < 10 then
        TriggerClientEvent('vorp:TipBottom', src, "Espere alguns segundos antes de tentar de novo.", 4000)
        return
    end
    cooldowns[src] = now

    local players = GetPlayers()
    local closest = nil
    local minDist = 2.0
    local pedCoords = GetEntityCoords(GetPlayerPed(src))
    for _, id in ipairs(players) do
        local target = tonumber(id)
        if target ~= src then
            local targetPed = GetPlayerPed(target)
            local targetCoords = GetEntityCoords(targetPed)
            local dist = #(pedCoords - targetCoords)
            if dist < minDist then
                closest = target
                minDist = dist
            end
        end
    end
    local targetId = closest
    if not targetId then
        TriggerClientEvent('vorp:TipBottom', src, "Ninguém por perto para beijar...", 4000)
        return
    end

    local srcName = GetCharacterName(src)
    local tgtName = GetCharacterName(targetId)
    local chance = math.random(1, 100)
    local resultado = ""
    if chance <= Config.PlayerChanceAceitar then
        TriggerClientEvent('kissme:startKiss', src, targetId)
        TriggerClientEvent('kissme:startKiss', targetId, src)
        resultado = "Beijo aceito"
    elseif chance <= (Config.PlayerChanceAceitar + Config.PlayerChanceDarTapa) then
        TriggerClientEvent('kissme:slapPlayer', targetId, src)
        resultado = "Levou um tapa"
    else
        TriggerClientEvent('vorp:TipBottom', src, "O outro jogador se afastou desconfortável...", 4000)
        resultado = "Beijo recusado"
    end
    sendWebhookLog(srcName, tgtName, resultado)
end)

exports("KissMe", function(playerId)
    TriggerClientEvent("kissme:tryKiss", playerId)
end)

RegisterNetEvent("kissme:giveLoot")
AddEventHandler("kissme:giveLoot", function()
    local src = source
    giveLootToPlayer(src)
end)


RegisterNetEvent("kissme:startDance")
AddEventHandler("kissme:startDance", function(targetId)
    TriggerClientEvent("kissme:syncDance", source)
    TriggerClientEvent("kissme:syncDance", targetId)
end)
