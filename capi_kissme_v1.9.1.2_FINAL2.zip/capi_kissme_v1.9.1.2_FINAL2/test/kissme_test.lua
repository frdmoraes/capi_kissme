RegisterCommand("kissme:test", function(source)
    local _source = source

    if not IsPlayerAceAllowed(_source, "capi_kissme.admin") then
        print("🚫 Você não tem permissão para executar os testes.")
        return
    end

    print("🔧 Iniciando testes avançados do capi_kissme...")

    -- Função de log via webhook
    local function sendWebhookLog(msg)
        PerformHttpRequest(Config.Webhook, function(err, text, headers) end, 'POST', json.encode({
            username = "KissMe Testes",
            embeds = {{
                title = "🧪 Log de Testes capi_kissme",
                description = msg,
                color = 16753920
            }}
        }), { ['Content-Type'] = 'application/json' })
    end

    sendWebhookLog("🔧 Testes iniciados por ID: " .. tostring(_source))

    -- Teste 1: Cooldown real
    local cooldownStart = os.time()
    Wait(3000)
    local cooldownElapsed = os.time() - cooldownStart
    print("🕒 Cooldown esperado: 3s / Decorrido:", cooldownElapsed, "s")

    -- Teste 2: Idioma
    local lang = GetConvar("locale", "en")
    print("🌐 Idioma atual:", lang)

    -- Teste 3: PlayerPedId e animação
    local ped = PlayerPedId()
    if ped and ped ~= -1 then
        print("✅ PlayerPedId encontrado.")
        local dict = "mech_reaction@shove@unarmed"
        local anim = "shove_var_a"
        RequestAnimDict(dict)
        while not HasAnimDictLoaded(dict) do Wait(10) end
        TaskPlayAnim(ped, dict, anim, 8.0, -8.0, 1000, 48, 0, false, false, false)
        print("🎭 Animação de teste executada.")
    end

    -- Teste 4: NPC detection
    local coords = GetEntityCoords(ped)
    local nearbyNpc = nil
    local peds = GetGamePool("CPed")
    for _, npc in ipairs(peds) do
        if not IsPedAPlayer(npc) and #(coords - GetEntityCoords(npc)) < 3.0 then
            nearbyNpc = npc
            break
        end
    end
    if nearbyNpc then
        print("🤖 NPC próximo detectado.")
        TaskTurnPedToFaceEntity(nearbyNpc, ped, 500)
        Wait(500)
        RequestAnimDict("ai_gestures@gen_male@farewell@casual")
        while not HasAnimDictLoaded("ai_gestures@gen_male@farewell@casual") do Wait(10) end
        TaskPlayAnim(nearbyNpc, "ai_gestures@gen_male@farewell@casual", "dismiss", 8.0, -8.0, 1000, 48, 0, false, false, false)
    else
        print("⚠️ Nenhum NPC próximo detectado para teste.")
    end

    -- Teste 5: Players
    local players = GetActivePlayers()
    local count = #players
    print("👥 Players conectados:", count)

    sendWebhookLog("✅ Testes concluídos por ID: " .. tostring(_source))
end, false)

Citizen.CreateThread(function()
    Wait(5000)
    TriggerServerEvent("kissme:runAdminTests")
end)